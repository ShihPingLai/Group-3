#this is the running script for our final project

python produce_signal.py
python Analysis_signal.py
